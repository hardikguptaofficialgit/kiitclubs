<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="login_styles.css">
   
    <script src="https://kit.fontawesome.com/1ab94d0eba.js" crossorigin="anonymous"></script>
</head>
<body>


<main class="container">
        <h2>Login</h2>
        <form action="admin_login.php" method="POST">
            <div class="input-field">
                <input type="text" name="username" id="username"
                    placeholder="Enter Your Username">
                <div class="underline"></div>
            </div>
            <div class="input-field">
                <input type="password" name="password" id="password"
                    placeholder="Enter Your Password">
                <div class="underline"></div>
            </div>

            <input type="submit" value="Continue">
        </form>

       
            </div>
        </div>
    </main>
    <?php
    session_start();
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $username = $_POST['username'];
        $password = $_POST['password'];

        // Check admin credentials
        if ($username === 'admin' && $password === 'admin') {
            $_SESSION['admin_logged_in'] = true;
            header('Location: admin_panel.php');
        } else {
            echo "<p class='error'>Invalid username or password.</p>";
        }
    }
    ?>

   
   
</body>
</html>
