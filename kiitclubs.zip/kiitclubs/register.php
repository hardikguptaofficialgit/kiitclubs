<?php
// Database configuration
$servername = "localhost"; // Change if necessary
$username = "root"; // Your database username
$password = ""; // Your database password
$dbname = "club_registrations"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO registrations (name, email, contact_number, roll_number, club, message) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssss", $name, $email, $contact_number, $roll_number, $club, $message);

// Get form data
$name = $_POST['name'];
$email = $_POST['email'];
$contact_number = $_POST['contact_number'];
$roll_number = $_POST['roll_number'];
$club = $_POST['club'];
$message = $_POST['message'];

// Execute the statement
if ($stmt->execute()) {
    echo "Registration successful! You will be notified shortly about your club registration . You can go back now .";
} else {
    echo "Error: " . $stmt->error;
}

// Close connections
$stmt->close();
$conn->close();
?>
